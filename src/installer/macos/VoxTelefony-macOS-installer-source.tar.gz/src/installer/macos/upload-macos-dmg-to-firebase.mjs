import fs from "node:fs";
import path from "node:path";
import process from "node:process";

const outputDir = path.resolve("src/installer/macos/output");
const dmg = fs.readdirSync(outputDir).find((name) => name.toLowerCase().endsWith(".dmg"));

if (!dmg) {
  throw new Error(`No .dmg found in ${outputDir}`);
}

const required = ["FIREBASE_SERVICE_ACCOUNT", "FIREBASE_STORAGE_BUCKET"];
for (const key of required) {
  if (!process.env[key]) throw new Error(`Missing ${key}`);
}

const [{ initializeApp, cert }, { getStorage }, { getFirestore }] = await Promise.all([
  import("firebase-admin/app"),
  import("firebase-admin/storage"),
  import("firebase-admin/firestore"),
]);

const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
const bucketName = process.env.FIREBASE_STORAGE_BUCKET;
const downloadsCollection = process.env.FIREBASE_DOWNLOADS_COLLECTION || "Downloads";
const version = process.env.APP_VERSION || "1.0.0";
const filePath = path.join(outputDir, dmg);
const storagePath = `installers/macos/${version}/${dmg}`;

initializeApp({
  credential: cert(serviceAccount),
  storageBucket: bucketName,
});

const bucket = getStorage().bucket();
await bucket.upload(filePath, {
  destination: storagePath,
  metadata: {
    contentType: "application/x-apple-diskimage",
    cacheControl: "public, max-age=31536000",
  },
});

const file = bucket.file(storagePath);
await file.makePublic();
const fileUrl = `https://storage.googleapis.com/${bucketName}/${encodeURIComponent(storagePath).replace(/%2F/g, "/")}`;

await getFirestore().collection(downloadsCollection).add({
  platform: "macOS",
  fileUrl,
  file_url: fileUrl,
  version,
  isActive: true,
  is_active: true,
  createdAt: new Date(),
  created_at: new Date(),
});

console.log(`Uploaded ${filePath}`);
console.log(`Download URL: ${fileUrl}`);
console.log(`Created macOS download record in ${downloadsCollection}`);
