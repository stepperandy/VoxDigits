# VoxTelefony macOS Installer

This folder contains the cloud build path for a signed and notarized macOS DMG.

The build must run on macOS. Use the GitHub Actions workflow:

`.github/workflows/build-macos-dmg.yml`

Required GitHub repository secrets:

- `APPLE_ID`
- `APPLE_APP_PASSWORD`
- `APPLE_TEAM_ID`
- `APPLE_SIGN_IDENTITY`
- `MACOS_CSC_LINK`
- `MACOS_CSC_KEY_PASSWORD`

Optional Firebase upload secrets:

- `FIREBASE_SERVICE_ACCOUNT`
- `FIREBASE_STORAGE_BUCKET`
- `FIREBASE_DOWNLOADS_COLLECTION`

Run the workflow manually and set:

- `version`: `1.0.0`
- `desktop_app_dir`: path to the Electron desktop app folder
- `upload_to_firebase`: `true` only after Firebase secrets are configured

Output DMG files are saved as workflow artifacts and, when enabled, uploaded to Firebase Storage.
