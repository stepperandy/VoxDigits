const { app, BrowserWindow, ipcMain, shell, session } = require("electron");
const path = require("path");

let introWindow = null;
let mainWindow = null;
let authWindow = null;
const desktopAuthCallbackUrl = "https://voxtelefony.desktop/auth-callback";
const base44AppId = "69b202c06dc5b1988efe9645";
const base44AppUrl = "https://voxtelefony.com";

function configureMediaPermissions() {
  const ses = session.defaultSession;

  ses.setPermissionRequestHandler((_webContents, permission, callback) => {
    callback(permission === "media");
  });

  ses.setPermissionCheckHandler((_webContents, permission) => {
    return permission === "media";
  });
}

function providerLoginPath(provider) {
  return provider === "google" ? "/api/apps/auth/login" : `/api/apps/auth/${provider}/login`;
}

function startProviderAuth(provider) {
  if (authWindow && !authWindow.isDestroyed()) authWindow.close();

  const authUrl = new URL(`${base44AppUrl}${providerLoginPath(provider)}`);
  authUrl.searchParams.set("app_id", base44AppId);
  authUrl.searchParams.set("from_url", desktopAuthCallbackUrl);

  authWindow = new BrowserWindow({
    width: 520,
    height: 720,
    title: "VoxTelefony Sign In",
    parent: mainWindow || undefined,
    modal: false,
    backgroundColor: "#07111f",
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  const finish = (rawUrl) => {
    let parsed;
    try {
      parsed = new URL(rawUrl);
    } catch {
      return false;
    }

    if (parsed.origin !== "https://voxtelefony.desktop" || parsed.pathname !== "/auth-callback") {
      return false;
    }

    const accessToken = parsed.searchParams.get("access_token");
    const isNewUser = parsed.searchParams.get("is_new_user");
    if (accessToken && mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send("auth:provider-token", {
        accessToken,
        provider,
        isNewUser: isNewUser === "true",
      });
    }

    if (authWindow && !authWindow.isDestroyed()) authWindow.close();
    authWindow = null;
    return true;
  };

  authWindow.webContents.on("will-redirect", (event, url) => {
    if (finish(url)) event.preventDefault();
  });

  authWindow.webContents.on("will-navigate", (event, url) => {
    if (finish(url)) event.preventDefault();
  });

  authWindow.on("closed", () => {
    authWindow = null;
  });

  authWindow.loadURL(authUrl.toString());
}

function createIntroWindow() {
  introWindow = new BrowserWindow({
    width: 520,
    height: 420,
    frame: false,
    resizable: false,
    show: false,
    backgroundColor: "#050b16",
    webPreferences: {
      preload: path.join(__dirname, "../preload/preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  introWindow.loadFile(path.join(__dirname, "../renderer/intro.html"));

  introWindow.once("ready-to-show", () => {
    introWindow.show();
  });
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1180,
    height: 760,
    minWidth: 1000,
    minHeight: 650,
    title: "VoxTelefony",
    backgroundColor: "#07111f",
    show: false,
    webPreferences: {
      preload: path.join(__dirname, "../preload/preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.loadFile(path.join(__dirname, "../renderer/index.html"));

  mainWindow.once("ready-to-show", () => {
    mainWindow.show();
  });
}

ipcMain.handle("intro:continue", () => {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.focus();
  } else {
    createMainWindow();
  }
  if (introWindow) {
    introWindow.close();
    introWindow = null;
  }
});

ipcMain.handle("window:minimize", () => {
  const win = BrowserWindow.getFocusedWindow();
  if (win) win.minimize();
});

ipcMain.handle("window:close", () => {
  const win = BrowserWindow.getFocusedWindow();
  if (win) win.close();
});

ipcMain.handle("app:getVersion", () => app.getVersion());

ipcMain.handle("auth:provider-login", (_event, provider) => {
  const allowedProviders = new Set(["google", "microsoft", "github"]);
  const selectedProvider = allowedProviders.has(provider) ? provider : "google";
  startProviderAuth(selectedProvider);
});

ipcMain.handle("app:openExternal", (_event, url) => {
  return shell.openExternal(url);
});

app.whenReady().then(() => {
  configureMediaPermissions();
  createIntroWindow();
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) createIntroWindow();
});
