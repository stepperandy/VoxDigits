const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("voxApp", {
  continueFromIntro: () => ipcRenderer.invoke("intro:continue"),
  minimize: () => ipcRenderer.invoke("window:minimize"),
  close: () => ipcRenderer.invoke("window:close"),
  getVersion: () => ipcRenderer.invoke("app:getVersion"),
  startProviderLogin: (provider) => ipcRenderer.invoke("auth:provider-login", provider),
  onProviderToken: (callback) => ipcRenderer.on("auth:provider-token", (_event, payload) => callback(payload)),
  openExternal: (url) => ipcRenderer.invoke("app:openExternal", url),
});
