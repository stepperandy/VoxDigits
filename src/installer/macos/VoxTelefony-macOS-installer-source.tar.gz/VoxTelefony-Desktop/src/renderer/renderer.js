const appId = "69b202c06dc5b1988efe9645";
const defaultBackendUrl = `https://voxtelefony.com/api/apps/${appId}`;
const twilioSdkUrl = "../../assets/twilio.min.js";

let backendUrl = localStorage.getItem("voxtelefony_backend") || defaultBackendUrl;
let accessToken = localStorage.getItem("voxtelefony_access_token") || "";
let currentUserEmail = localStorage.getItem("voxtelefony_user_email") || "";
let callerId = localStorage.getItem(numberStorageKey()) || localStorage.getItem("voxtelefony_caller_id") || "";
let currentCall = null;
let incomingCall = null;
let twilioDevice = null;
let ownedNumbers = [];
const historyItems = JSON.parse(localStorage.getItem("voxtelefony_history") || "[]");

const contacts = [];

function numberStorageKey(email = currentUserEmail) {
  return `voxtelefony_caller_id:${String(email || "default").trim().toLowerCase()}`;
}

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));

function saveHistory() {
  localStorage.setItem("voxtelefony_history", JSON.stringify(historyItems.slice(0, 30)));
}

function addHistory(type, detail, status) {
  historyItems.unshift({ type, detail, status, time: new Date().toLocaleString() });
  saveHistory();
  renderHistory();
}

function renderContacts() {
  $("#contactsList").innerHTML = contacts.map((contact) => `
    <div class="list-item">
      <div>
        <strong>${contact.name}</strong>
        <span>${contact.phone}</span>
      </div>
      <button type="button" class="contact-call" data-phone="${contact.phone}">Call</button>
    </div>
  `).join("");

  $$(".contact-call").forEach((button) => {
    button.addEventListener("click", () => {
      $("#phoneNumber").value = button.dataset.phone;
      showScreen("dialer");
      $("#callBtn").click();
    });
  });
}

function renderHistory() {
  $("#historyList").innerHTML = historyItems.length
    ? historyItems.map((item) => `
      <div class="list-item">
        <div>
          <strong>${item.type}: ${item.detail}</strong>
          <span>${item.time}</span>
        </div>
        <span>${item.status}</span>
      </div>
    `).join("")
    : "";
}

function escapeHtml(value) {
  return String(value || "").replace(/[&<>"]/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "\"": "&quot;",
  }[char]));
}

function readNumberValue(item) {
  if (typeof item === "string") return normalizePhone(item);
  if (!item || typeof item !== "object") return "";

  const raw = item.phone_number || item.phoneNumber || item.number || item.e164 || item.phone || item.value || item.from_number || item.our_number || "";
  return normalizePhone(raw);
}

function readNumberLabel(item, value) {
  if (!item || typeof item !== "object") return value;
  return item.friendly_name || item.friendlyName || item.label || item.name || value;
}

function readBoolean(value) {
  if (value === true || value === "true" || value === 1 || value === "1") return true;
  if (value === false || value === "false" || value === 0 || value === "0") return false;
  return null;
}

function readNumberCapability(item, capability) {
  if (!item || typeof item !== "object") return null;
  const caps = item.capabilities || item.capability || {};
  const keys = capability === "sms"
    ? ["sms", "SMS", "mms", "MMS", "sms_enabled", "smsEnabled", "can_sms", "canSms"]
    : ["voice", "Voice", "voice_enabled", "voiceEnabled", "can_voice", "canVoice"];

  for (const key of keys) {
    if (Object.prototype.hasOwnProperty.call(item, key)) {
      const value = readBoolean(item[key]);
      if (value !== null) return value;
    }
    if (Object.prototype.hasOwnProperty.call(caps, key)) {
      const value = readBoolean(caps[key]);
      if (value !== null) return value;
    }
  }

  return null;
}

function extractNumberItems(payload) {
  const candidates = [
    payload,
    payload && payload.data,
    payload && payload.data && payload.data.data,
    payload && payload.data && payload.data.numbers,
    payload && payload.data && payload.data.phone_numbers,
    payload && payload.data && payload.data.phoneNumbers,
    payload && payload.data && payload.data.ownedNumbers,
    payload && payload.numbers,
    payload && payload.phone_numbers,
    payload && payload.phoneNumbers,
    payload && payload.ownedNumbers,
    payload && payload.results,
    payload && payload.items,
  ];

  for (const candidate of candidates) {
    if (Array.isArray(candidate)) return candidate;
  }

  return [];
}

function normalizeNumberItems(items) {
  const seen = new Set();
  return items.map((item) => {
    const value = readNumberValue(item);
    const label = readNumberLabel(item, value);
    return value ? {
      value,
      label,
      smsCapable: readNumberCapability(item, "sms"),
      voiceCapable: readNumberCapability(item, "voice"),
      status: item && typeof item === "object" ? item.status || item.state || "" : "",
      raw: item,
    } : null;
  }).filter((item) => {
    if (!item || seen.has(item.value)) return false;
    seen.add(item.value);
    return true;
  });
}

function renderNumbers() {
  const savedCallerId = localStorage.getItem(numberStorageKey()) || localStorage.getItem("voxtelefony_caller_id") || "";
  if (!callerId && savedCallerId) callerId = savedCallerId;

  const fallback = callerId ? [{ value: callerId, label: callerId, smsCapable: null, voiceCapable: null }] : [];
  const numbers = ownedNumbers.length ? ownedNumbers : fallback;
  const voiceNumbers = numbers.filter((item) => item.voiceCapable !== false);
  const smsNumbers = numbers.filter((item) => item.smsCapable !== false);
  const makeOptions = (items, type) => items.map((item) => {
    const value = item.value || readNumberValue(item);
    const label = item.label || readNumberLabel(item, value);
    const capability = type === "sms" ? item.smsCapable : item.voiceCapable;
    const suffix = capability === true ? " ready" : "";
    return value ? `<option value="${escapeHtml(value)}">${escapeHtml(label)}${label !== value ? ` (${escapeHtml(value)})` : ""}${suffix}</option>` : "";
  }).join("");

  $("#callerSelect").innerHTML = makeOptions(voiceNumbers, "voice") || `<option value="">No VoxTelefony number found</option>`;
  $("#smsFrom").innerHTML = makeOptions(smsNumbers, "sms") || `<option value="">No SMS-enabled VoxTelefony number found</option>`;

  const hasSavedNumber = numbers.some((item) => (item.value || readNumberValue(item)) === callerId);
  if (!callerId || !hasSavedNumber) {
    callerId = numbers[0] ? numbers[0].value || readNumberValue(numbers[0]) : "";
  }

  if (callerId) {
    $("#callerSelect").value = callerId;
    $("#smsFrom").value = callerId;
    localStorage.setItem(numberStorageKey(), callerId);
      localStorage.setItem("voxtelefony_caller_id", callerId);
  }

  $("#callerId").value = callerId;
}

function showScreen(screenId) {
  $$(".screen").forEach((screen) => screen.classList.add("hidden"));
  $(`#${screenId}`).classList.remove("hidden");

  $$(".nav").forEach((button) => {
    button.classList.toggle("active", button.dataset.screen === screenId);
  });
}

function showAuthed() {
  $("#authScreen").classList.add("hidden");
  $("#appShell").classList.remove("hidden");
  callerId = localStorage.getItem(numberStorageKey()) || localStorage.getItem("voxtelefony_caller_id") || callerId;
  loadSettings();
  renderNumbers();
  loadOwnedNumbers();
  registerIncomingCalls();
}

function showLogin() {
  $("#appShell").classList.add("hidden");
  $("#authScreen").classList.remove("hidden");
}

function normalizePhone(value) {
  const raw = String(value || "").trim();
  const cleaned = raw.replace(/[^\d+#*]/g, "");
  return raw.startsWith("+") ? `+${cleaned.replace(/^\+/, "")}` : cleaned;
}

function appUrl(path) {
  return `${backendUrl.replace(/\/+$/, "")}${path}`;
}

function authHeaders() {
  const headers = {
    "Content-Type": "application/json",
    "Accept": "application/json",
    "X-App-Id": appId,
    "Base44-Functions-Version": "prod",
  };

  if (accessToken) {
    headers.Authorization = `Bearer ${accessToken}`;
  }

  return headers;
}

function getBackendErrorMessage(data, fallback) {
  return (data && (
    data.error ||
    data.message ||
    data.detail ||
    (data.data && (data.data.error || data.data.message || data.data.detail)) ||
    (data.response && data.response.data && (data.response.data.error || data.response.data.message))
  )) || fallback;
}

function isTwilioCombinationError(error) {
  const raw = error && (error.message || String(error));
  return /current combination of 'To'.*'From'|current combination/i.test(raw);
}

function formatSmsError(error, from, to, attemptedSenders = []) {
  const raw = error && (error.message || String(error));
  if (isTwilioCombinationError(error)) {
    const tried = attemptedSenders.length ? ` Tried: ${attemptedSenders.join(", ")}.` : "";
    return `SMS is blocked by Twilio for From ${from} to To ${to}.${tried} This sender is not accepted for that destination route. The app tried every available SMS-enabled VoxTelefony sender. If geo permissions are already enabled, check sender SMS capability, Messaging Service routing, A2P/brand registration requirements, and whether Twilio allows that sender type for the destination.`;
  }
  if (/not a valid phone number|invalid.*phone/i.test(raw)) {
    return "Enter the recipient in full international format, for example +15551234567.";
  }
  return raw || "Failed to send SMS.";
}

function getSmsSenderCandidates(selectedFrom) {
  const selected = normalizePhone(selectedFrom);
  const numbers = ownedNumbers.length ? ownedNumbers : [];
  const candidates = [];

  if (selected) candidates.push(selected);

  numbers
    .filter((item) => item && item.smsCapable !== false)
    .map((item) => normalizePhone(item.value || readNumberValue(item)))
    .filter(Boolean)
    .forEach((value) => {
      if (!candidates.includes(value)) candidates.push(value);
    });

  return candidates;
}

async function sendSmsWithSender(from, to, message) {
  const result = await invokeFunction("sendSms", {
    from,
    to,
    message,
    from_number: from,
    to_number: to,
    body: message,
  });
  if (result && result.data && result.data.error) {
    throw new Error(result.data.error);
  }
  return result;
}

async function postApp(path, payload) {
  const response = await fetch(appUrl(path), {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify(payload || {}),
  });
  const data = await response.json().catch(() => ({}));

  if (!response.ok || data.error || (data.data && data.data.error)) {
    throw new Error(getBackendErrorMessage(data, `Backend returned ${response.status}`));
  }

  return data;
}

async function getApp(path) {
  const response = await fetch(appUrl(path), {
    method: "GET",
    headers: authHeaders(),
  });
  const data = await response.json().catch(() => ({}));

  if (!response.ok || data.error || (data.data && data.data.error)) {
    throw new Error(getBackendErrorMessage(data, `Backend returned ${response.status}`));
  }

  return data;
}

async function invokeFunction(name, payload) {
  return postApp(`/functions/${name}`, payload);
}

function handleProviderToken(payload) {
  if (!payload || !payload.accessToken) return;

  accessToken = payload.accessToken;
  currentUserEmail = `${payload.provider || "provider"}-user`;
  localStorage.setItem("voxtelefony_access_token", accessToken);
  localStorage.setItem("voxtelefony_user_email", currentUserEmail);
  $("#accessToken").value = accessToken;
  $("#loginMsg").textContent = payload.isNewUser ? "Account created." : "";
  showAuthed();
}

function startProviderLogin(provider) {
  const msg = $("#loginMsg");
  msg.textContent = `Opening ${provider} sign in...`;

  if (!window.voxApp || !window.voxApp.startProviderLogin) {
    msg.textContent = "Provider login is not available in this build.";
    return;
  }

  window.voxApp.startProviderLogin(provider);
}

async function login() {
  const email = $("#loginEmail").value.trim();
  const password = $("#loginPassword").value;
  const msg = $("#loginMsg");

  if (!email || !password) {
    msg.textContent = "Enter email and password.";
    return;
  }

  msg.textContent = "Logging in...";

  try {
    const data = await postApp("/auth/login", { email, password });
    currentUserEmail = email;
    localStorage.setItem("voxtelefony_user_email", currentUserEmail);
    accessToken = data.access_token || data.token || (data.data && (data.data.access_token || data.data.token)) || "";
    if (!accessToken) throw new Error("No access token returned.");
    localStorage.setItem("voxtelefony_access_token", accessToken);
    $("#accessToken").value = accessToken;
    msg.textContent = "";
    showAuthed();
  } catch (error) {
    msg.textContent = error.message || "Login failed.";
  }
}

async function loadOwnedNumbers() {
  if (!accessToken) return;

  const msg = $("#callMsg");
  if (msg) msg.textContent = "Loading VoxTelefony numbers...";

  try {
    const data = await invokeFunction("getOwnedNumbers", {});
    ownedNumbers = normalizeNumberItems(extractNumberItems(data));
    renderNumbers();
    if (msg) msg.textContent = ownedNumbers.length ? `${ownedNumbers.length} VoxTelefony number${ownedNumbers.length === 1 ? "" : "s"} loaded.` : "No VoxTelefony number found for this account.";
  } catch (error) {
    renderNumbers();
    if (msg) msg.textContent = error.message || "Could not load VoxTelefony numbers.";
  }
}

function readTwilioToken(payload) {
  return payload && (
    payload.token ||
    payload.accessToken ||
    (payload.data && (payload.data.token || payload.data.accessToken)) ||
    (payload.data && payload.data.data && (payload.data.data.token || payload.data.data.accessToken))
  );
}

async function ensureMicrophoneAccess() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    throw new Error("Microphone access is not available in this app window.");
  }

  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  stream.getTracks().forEach((track) => track.stop());
}

function setCallStatus(message) {
  const msg = $("#callMsg");
  if (msg) msg.textContent = message;
}

function getIncomingFrom(call) {
  return call && call.parameters && (call.parameters.From || call.parameters.Caller || call.parameters.CallerId) || "Unknown caller";
}

function showIncomingCall(call) {
  incomingCall = call;
  const panel = $("#incomingCallPanel");
  const from = getIncomingFrom(call);
  if (panel) panel.classList.remove("hidden");
  const label = $("#incomingFrom");
  if (label) label.textContent = from;
  setCallStatus(`Incoming call from ${from}.`);
  showScreen("dialer");
}

function hideIncomingCall() {
  incomingCall = null;
  const panel = $("#incomingCallPanel");
  if (panel) panel.classList.add("hidden");
  const label = $("#incomingFrom");
  if (label) label.textContent = "";
}

function attachIncomingEvents(call) {
  if (!call || typeof call.on !== "function") return;
  const from = getIncomingFrom(call);

  call.on("accept", () => {
    currentCall = call;
    hideIncomingCall();
    setCallStatus("Incoming call connected.");
    addHistory("Incoming call", from, "Connected");
  });

  call.on("disconnect", () => {
    currentCall = null;
    hideIncomingCall();
    setCallStatus("Incoming call ended.");
  });

  call.on("cancel", () => {
    hideIncomingCall();
    setCallStatus("Incoming call cancelled.");
  });

  call.on("reject", () => {
    hideIncomingCall();
    setCallStatus("Incoming call rejected.");
  });

  call.on("error", (error) => {
    currentCall = null;
    hideIncomingCall();
    setCallStatus(error.message || "Incoming call failed.");
    addHistory("Incoming call", from, "Failed");
  });
}

function attachCallEvents(call, to) {
  if (!call || typeof call.on !== "function") return;

  call.on("accept", () => {
    setCallStatus("Connected.");
    addHistory("Call", to, "Connected");
  });

  call.on("ringing", () => {
    setCallStatus("Ringing...");
  });

  call.on("disconnect", () => {
    currentCall = null;
    setCallStatus("Call ended.");
  });

  call.on("cancel", () => {
    currentCall = null;
    setCallStatus("Call cancelled.");
  });

  call.on("error", (error) => {
    currentCall = null;
    setCallStatus(error.message || "Call failed.");
    addHistory("Call", to, "Failed");
  });
}

function loadTwilioSdk() {
  if (window.Twilio && window.Twilio.Device) return Promise.resolve();

  return new Promise((resolve, reject) => {
    const existing = document.querySelector(`script[src="${twilioSdkUrl}"]`);
    if (existing) {
      existing.addEventListener("load", resolve, { once: true });
      existing.addEventListener("error", reject, { once: true });
      return;
    }

    const script = document.createElement("script");
    script.src = twilioSdkUrl;
    script.async = true;
    script.onload = resolve;
    script.onerror = () => reject(new Error("Twilio SDK failed to load."));
    document.head.appendChild(script);
  });
}

async function getTwilioDevice() {
  await loadTwilioSdk();
  const tokenResponse = await invokeFunction("twilioToken", {});
  const token = readTwilioToken(tokenResponse);
  if (!token) throw new Error("No Twilio token returned.");

  if (twilioDevice && typeof twilioDevice.destroy === "function") {
    twilioDevice.destroy();
  }

  const Device = window.Twilio.Device;
  twilioDevice = new Device(token, { logLevel: 1, sounds: { incoming: false, outgoing: false, disconnect: false } });

  twilioDevice.on("registered", () => setCallStatus("Ready for calls."));
  twilioDevice.on("unregistered", () => setCallStatus("Call device disconnected."));
  twilioDevice.on("error", (error) => setCallStatus(error.message || "Call device error."));
  twilioDevice.on("incoming", (call) => {
    attachIncomingEvents(call);
    showIncomingCall(call);
  });
  twilioDevice.on("disconnect", () => {
    currentCall = null;
    setCallStatus("Call ended.");
  });

  if (typeof twilioDevice.register === "function") {
    await twilioDevice.register();
  }

  return twilioDevice;
}

async function registerIncomingCalls() {
  if (!accessToken) return;
  try {
    setCallStatus("Registering incoming calls...");
    await getTwilioDevice();
  } catch (error) {
    setCallStatus(error.message || "Incoming call registration failed.");
  }
}

async function acceptIncomingCall() {
  const call = incomingCall;
  if (!call) return;

  try {
    await ensureMicrophoneAccess();
    if (typeof call.accept === "function") {
      await call.accept();
    }
    currentCall = call;
    hideIncomingCall();
    setCallStatus("Incoming call connected.");
  } catch (error) {
    setCallStatus(error.message || "Could not answer incoming call.");
  }
}

function rejectIncomingCall() {
  const call = incomingCall;
  if (call && typeof call.reject === "function") {
    call.reject();
  } else if (call && typeof call.disconnect === "function") {
    call.disconnect();
  }
  hideIncomingCall();
  setCallStatus("Incoming call rejected.");
}

async function startCall() {
  const to = normalizePhone($("#phoneNumber").value);
  const from = normalizePhone($("#callerSelect").value || callerId);
  const msg = $("#callMsg");

  if (!accessToken) {
    msg.textContent = "Login required.";
    showLogin();
    return;
  }

  if (!to) {
    msg.textContent = "Enter a number.";
    return;
  }

  if (!from) {
    msg.textContent = "Select your VoxTelefony number.";
    return;
  }

  $("#phoneNumber").value = to;
  msg.textContent = "Connecting...";

  try {
    msg.textContent = "Checking microphone...";
    await ensureMicrophoneAccess();
    msg.textContent = "Registering call device...";
    const device = await getTwilioDevice();
    msg.textContent = "Dialing...";
    currentCall = await device.connect({ params: { To: to, PhoneNumber: to, callerId: from } });
    attachCallEvents(currentCall, to);
  } catch (error) {
    msg.textContent = error.message || "Call failed.";
    addHistory("Call", to, "Failed");
  }
}

function hangupCall() {
  if (currentCall && typeof currentCall.disconnect === "function") {
    currentCall.disconnect();
  }
  if (twilioDevice && typeof twilioDevice.disconnectAll === "function") {
    twilioDevice.disconnectAll();
  }
  currentCall = null;
  $("#callMsg").textContent = "Call ended.";
}

async function sendSms() {
  const from = normalizePhone($("#smsFrom").value || callerId);
  const to = normalizePhone($("#smsTo").value);
  const message = $("#smsMessage").value.trim();
  const msg = $("#smsMsg");

  if (!accessToken) {
    msg.textContent = "Login required.";
    showLogin();
    return;
  }

  if (!from || !to || !message) {
    msg.textContent = "Enter from, to, and message.";
    return;
  }

  msg.textContent = "Sending...";

  const attemptedSenders = [];
  let lastError = null;

  try {
    const candidates = getSmsSenderCandidates(from);
    if (!candidates.length) throw new Error("No SMS-enabled VoxTelefony sender is available.");

    for (const sender of candidates) {
      attemptedSenders.push(sender);
      try {
        await sendSmsWithSender(sender, to, message);
        callerId = sender;
        $("#smsFrom").value = sender;
        localStorage.setItem(numberStorageKey(), sender);
        localStorage.setItem("voxtelefony_caller_id", sender);
        $("#smsMessage").value = "";
        msg.textContent = sender === from ? "Sent." : `Sent using ${sender}.`;
        addHistory("SMS", to, "Sent");
        return;
      } catch (error) {
        lastError = error;
        if (!isTwilioCombinationError(error)) throw error;
      }
    }

    throw lastError || new Error("No SMS route accepted this message.");
  } catch (error) {
    msg.textContent = formatSmsError(error, from, to, attemptedSenders);
    addHistory("SMS", to, "Failed");
  }
}

function loadSettings() {
  $("#backendUrl").value = backendUrl;
  $("#accessToken").value = accessToken;
  $("#callerId").value = callerId;
}

function saveSettings() {
  backendUrl = $("#backendUrl").value.trim().replace(/\/+$/, "") || defaultBackendUrl;
  accessToken = $("#accessToken").value.trim();
  callerId = normalizePhone($("#callerId").value);

  localStorage.setItem("voxtelefony_backend", backendUrl);
  localStorage.setItem("voxtelefony_access_token", accessToken);
  localStorage.setItem(numberStorageKey(), callerId);
    localStorage.setItem("voxtelefony_caller_id", callerId);

  loadSettings();
  renderNumbers();
  $("#settingsMsg").textContent = "Saved.";
}

function logout() {
  accessToken = "";
  currentCall = null;
  hideIncomingCall();
  if (twilioDevice && typeof twilioDevice.destroy === "function") {
    twilioDevice.destroy();
  }
  twilioDevice = null;
  localStorage.removeItem("voxtelefony_access_token");
  $("#loginPassword").value = "";
  showLogin();
}

function bindEvents() {
  $$(".nav").forEach((button) => {
    button.addEventListener("click", () => showScreen(button.dataset.screen));
  });

  $$(".dial-grid button").forEach((button) => {
    button.addEventListener("click", () => {
      $("#phoneNumber").value += button.textContent;
      $("#phoneNumber").focus();
    });
  });

  $("#loginBtn").addEventListener("click", login);
  $$(".provider-login").forEach((button) => {
    button.addEventListener("click", () => startProviderLogin(button.dataset.provider));
  });
  $("#loginPassword").addEventListener("keydown", (event) => {
    if (event.key === "Enter") login();
  });

  $("#backspaceBtn").addEventListener("click", () => {
    $("#phoneNumber").value = $("#phoneNumber").value.slice(0, -1);
    $("#phoneNumber").focus();
  });

  $("#clearBtn").addEventListener("click", () => {
    $("#phoneNumber").value = "";
    $("#callMsg").textContent = "";
    $("#phoneNumber").focus();
  });

  $("#callerSelect").addEventListener("change", () => {
    callerId = normalizePhone($("#callerSelect").value);
    localStorage.setItem(numberStorageKey(), callerId);
    localStorage.setItem("voxtelefony_caller_id", callerId);
  });

  $("#smsFrom").addEventListener("change", () => {
    callerId = normalizePhone($("#smsFrom").value);
    localStorage.setItem(numberStorageKey(), callerId);
    localStorage.setItem("voxtelefony_caller_id", callerId);
    renderNumbers();
  });

  $("#callBtn").addEventListener("click", startCall);
  $("#hangupBtn").addEventListener("click", hangupCall);
  $("#acceptIncomingBtn").addEventListener("click", acceptIncomingCall);
  $("#rejectIncomingBtn").addEventListener("click", rejectIncomingCall);
  $("#sendSmsBtn").addEventListener("click", sendSms);
  $("#saveSettingsBtn").addEventListener("click", saveSettings);
  $("#logoutBtn").addEventListener("click", logout);
}

loadSettings();
renderContacts();
renderHistory();
bindEvents();

if (window.voxApp && window.voxApp.onProviderToken) {
  window.voxApp.onProviderToken(handleProviderToken);
}

if (accessToken) {
  showAuthed();
} else {
  showLogin();
}

showScreen("dialer");
