!macro customHeader
  BrandingText "VoxTelefony | Secure Voice and SMS"
!macroend

!macro customInstall
  DetailPrint "Installing VoxTelefony native voice and SMS desktop app..."
!macroend

!macro customUnInstall
  DetailPrint "Removing VoxTelefony..."
!macroend
