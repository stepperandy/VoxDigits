# VoxTelefony Installer With Intro

This package contains the redesigned VoxTelefony desktop app with:

- Custom intro screen
- Unique VoxTelefony logo
- Dark blue/purple telephony background
- Dial pad screen
- SMS screen
- Contacts/history/settings placeholders
- Windows NSIS installer setup

## Run app

```bash
npm install
npm run dev
```

## Build Windows installer

```bash
npm run dist
```

The installer will be created inside:

```txt
dist/
```

## Important

This version includes the frontend installer/app shell.
Provider credentials must stay in backend `.env`, not in this desktop app.
